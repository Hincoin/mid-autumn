#!/bin/bash



SRC_PATH=~/mid-autumn
DEST_PATH=~/

find $SRC_PATH -path "*.svn*" -prune -o -path "*extern*" -prune -o -name "*.h" -o -name "*.hpp" -type f -printf "%f\t%p\t1\n" > $SRC_PATH/tmp.txt
find $SRC_PATH -path "*.svn*" -prune -o -path "*extern*" -prune -o -name "*.cpp" -type f -printf "%f\t%p\t1\n" >> $SRC_PATH/tmp.txt

#@echo off rem find.exe S:\trunk\design\data\Server -name "*.h" -o -name "*.cpp" -o -name "*.lua" -type f -printf "%%f\t%%p\t1\n" >> d:\Tools\Vim\game\temp.txt

echo -e "!_TAG_FILE_SORTED\t2\t/2=foldcase/" > $DEST_PATH/filename_list.txt
cat $SRC_PATH/tmp.txt | sort -f >> $DEST_PATH/filename_list.txt

rm $SRC_PATH/tmp.txt

find $SRC_PATH -path "*.svn*" -prune -o -path "*extern*" -prune -o -name "*.hpp" -o -name "*.h" -o -name "*.cpp" -print0 > $DEST_PATH/fileindex_list.txt
#@echo off rem find.exe S:\trunk\design\data\Server -name "*.h" -o -name "*.cpp" -o -name "*.lua" -print0 >> d:\tools\vim\game\filelist.txt

cd $SRC_PATH
ctags -R --exclude=.svn --exclude=extern --c++-kinds=+p --totals=yes --tag-relative=yes --fields=+iaS --extra=+q -f $DEST_PATH/default_tags




